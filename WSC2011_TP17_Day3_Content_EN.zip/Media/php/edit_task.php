<? 
	include ("config/db_conn.php");
	
	mysql_query("UPDATE tasks SET TaskDescription='$_POST[TaskDescription]',StartTime='$_POST[StartTime]',EndTime='$_POST[EndTime]',SortOrder=$_POST[SortOrder],ResponsibleId=$_POST[ResponsibleId] WHERE TaskId=$_POST[TaskId]") or die (mysql_error());
?>